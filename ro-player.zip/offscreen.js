// offscreen.js
document.addEventListener('DOMContentLoaded', () => {
  const audioPlayer = document.getElementById('backgroundPlayer');
  
  if (!audioPlayer) {
    console.error('Background audio player element not found!');
    return;
  }

  // Обработка сообщений от основного скрипта
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type == 'PLAY_AUDIO') {
      // Воспроизведение аудио в фоне
      audioPlayer.src = message.url;
      audioPlayer.load();
      audioPlayer.play().catch(e => {
        console.error('Background playback failed:', e);
      });
    }
    if (message.type == 'PAUSE_AUDIO') {
      if (audioPlayer.paused !== true) {
        audioPlayer.pause();
      }
      else {
        audioPlayer.play();
      }
    }
    if (message.type == 'STOP_AUDIO') {
      audioPlayer.pause();
      audioPlayer.currentTime = 0;
    }
    if (message.type == 'MUTE_AUDIO') {
      audioPlayer.muted = message.mut;
    }
    if (message.type == 'LOOP_AUDIO') {
      audioPlayer.loop = message.lop;
    }
    if (message.type == 'VOLUME_AUDIO') {
      audioPlayer.volume = message.vol;
    }
    if (message.type == 'POSITION_AUDIO') {
      audioPlayer.currentTime = message.pos;
    }
  });

  // Управление состоянием воспроизведения
  audioPlayer.addEventListener('ended', () => {
    chrome.runtime.sendMessage({
      type: 'AUDIO_ENDED'
    });
  });

  audioPlayer.addEventListener('pause', () => {
    chrome.runtime.sendMessage({
      type: 'AUDIO_PAUSED'
    });
  });

  audioPlayer.addEventListener('play', () => {
    chrome.runtime.sendMessage({
      type: 'AUDIO_PLAYING'
    });
  });
});