const CACHE_NAME = 'rage_audio_cache';

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "GET_AUDIO_URL") {
    const assetUrl = `https://assetdelivery.roblox.com/v1/asset/?id=${request.id}`;
    
    caches.open(CACHE_NAME).then(cache => {
      cache.match(assetUrl).then(response => {
        if (response) {
          sendResponse({ url: assetUrl });
          return;
        }
        
        // Если нет в кеше - загружаем и кешируем
        fetch(assetUrl)
          .then(networkResponse => {
            cache.put(assetUrl, networkResponse.clone());
            sendResponse({ url: assetUrl });
          })
          .catch(error => {
            sendResponse({ error: `Fetch failed: ${error.message}` });
          });
      });
    });
    
    return true; // Асинхронный ответ
  }
  
  if (request.action === "CLEAR_CACHE") {
    caches.delete(CACHE_NAME)
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
});