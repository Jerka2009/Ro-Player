const CACHE_NAME = 'rage_audio_cache';

// 1. Функция для получения аудио с авторизацией
async function fetchWithAuth(url) {
  try {
    const cookies = await chrome.cookies.getAll({
      domain: '.roblox.com',
      name: '.ROBLOSECURITY'
    });
    
    if (!cookies || cookies.length === 0) {
      throw new Error('ROBLOSECURITY cookie not found. Login to Roblox first!');
    }
    
    const robloSecurity = cookies[0].value;
    
    const response = await fetch(url, {
      headers: { 'Cookie': `.ROBLOSECURITY=${robloSecurity}` }
    });
    
    if (response.status === 403) {
      const errorData = await response.json();
      throw new Error(errorData.errors[0].message);
    }
    
    return response;
  } catch (error) {
    throw new Error(`Auth failed: ${error.message}`);
  }
}

// 2. Функция для получения прямых ссылок на длинные аудио
async function getRobloxAudioUrl(id) {
  const API_URL = `https://catalog.roblox.com/v1/catalog/items/${id}/details?itemType=Asset`;
  
  try {
    const response = await fetch(API_URL);
    const data = await response.json();
    
    if (!data || !data.media || !data.media[0]) {
      throw new Error('Audio metadata not found');
    }
    
    // Ищем рабочую ссылку
    for (const mediaItem of data.media) {
      if (mediaItem.mediaUrl && mediaItem.mediaUrl.includes('rbxcdn.com')) {
        const testResponse = await fetch(mediaItem.mediaUrl, { method: 'HEAD' });
        if (testResponse.ok) return mediaItem.mediaUrl;
      }
    }
    
    throw new Error('No valid direct URL found');
  } catch (error) {
    throw new Error(`Metadata fetch failed: ${error.message}`);
  }
}

// Создаем offscreen document для фонового воспроизведения
async function setupOffscreenDocument() {
  if (await chrome.offscreen.hasDocument()) return;
  
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['AUDIO_PLAYBACK'],
    justification: 'Background audio playback'
  });
}

// Отправка аудио в фоновый документ
async function playAudioInBackground(url) {
  await setupOffscreenDocument();
  //await new Promise(resolve => setTimeout(resolve, 100));
  chrome.runtime.sendMessage({
    type: 'PLAY_AUDIO',
    target: 'offscreen',
    url: url
  });
}

// Основной обработчик сообщений
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "GET_AUDIO_URL") {
    (async () => {
      try {
        // Попытка 1: Получение через метаданные (для длинных аудио)
        const directUrl = await getRobloxAudioUrl(request.id);
        
        sendResponse({ url: directUrl });
      } catch (directError) {
        // Попытка 2: Стандартный метод (для коротких аудио)
        const assetUrl = `https://assetdelivery.roblox.com/v1/asset/?id=${request.id}`;
        
        try {
          let response = await fetch(assetUrl);
          
          // Если доступ запрещен - пробуем с авторизацией
          if (response.status === 403) {
            response = await fetchWithAuth(assetUrl);
          }
          
          if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
          
          // Кешируем
          const cache = await caches.open(CACHE_NAME);
          await cache.put(assetUrl, response.clone());
          
          sendResponse({ url: assetUrl });
        } catch (standardError) {
          sendResponse({
            error: `${standardError.message}` //Failed to get audio: ${directError.message} AND 
          });
        }
      }
    })();
    
    return true;
  }
  
  // Воспроизведение в фоне
  if (request.action === "PLAY_IN_BACKGROUND") {
    playAudioInBackground(request.url);
    sendResponse({ status: "playing" });
    return true;
  }
  if (request.action === "POSITION_IN_BACKGROUND") {
    chrome.runtime.sendMessage({
      type: 'POSITION_AUDIO',
      target: 'offscreen',
      pos: request.positi
    });
    return true;
  }
  if (request.action === "PAUSE_IN_BACKGROUND") {
    chrome.runtime.sendMessage({
      type: 'PAUSE_AUDIO',
      target: 'offscreen',
    });
    return true;
  }
  if (request.action === "STOP_IN_BACKGROUND") {
    chrome.runtime.sendMessage({
      type: 'STOP_AUDIO',
      target: 'offscreen',
    });
    return true;
  }
  if (request.action === "VOLUME_IN_BACKGROUND") {
    chrome.runtime.sendMessage({
      type: 'VOLUME_AUDIO',
      target: 'offscreen',
      vol: request.vol
    });
    return true;
  }
  if (request.action === "Mute_IN_BACKGROUND") {
    chrome.runtime.sendMessage({
      type: 'MUTE_AUDIO',
      target: 'offscreen',
      mut: request.mut
    });
    return true;
  }
  if (request.action === "LOOP_IN_BACKGROUND") {
    chrome.runtime.sendMessage({
      type: 'LOOP_AUDIO',
      target: 'offscreen',
      lop: request.lop
    });
    return true;
  }
});