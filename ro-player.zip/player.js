// player.js
document.addEventListener('DOMContentLoaded', () => {
  // Elements
  const audioIdInput = document.getElementById('audioId');
  const playBtn = document.getElementById('playBtn');
  const progress = document.getElementById('progress');
  const progressBar = document.getElementById('progress-bar');
  const volume = document.getElementById('volume');
  const volumeLevel = document.getElementById('volume-level');
  const volumeText = document.getElementById('volume-text');
  const timeDisplay = document.getElementById('time');
  const statusDisplay = document.getElementById('status');
  const audioPlayer = document.getElementById('audioPlayer');
  const muteBtn = document.getElementById('muteBtn');
  const loopBtn = document.getElementById('loopBtn');
  const miniBtn = document.getElementById('miniBtn');

  // Проверка существования элементов
  if (!playBtn || !audioPlayer) {
    console.error('Critical elements not found!');
    return;
  }
  
  // Player state
  let currentAudioId = null;
  let isPlaying = false;
  let isMuted = false;
  let isLooping = false;
  let currentVolume = 0.8;

  
  // Initialize player
  const initPlayer = () => {
    audioPlayer.volume = currentVolume;
    volumeLevel.style.width = `${currentVolume * 100}%`;
    volumeText.textContent = `${Math.round(currentVolume * 100)}%`;
  };
  
  // Play button handler
  playBtn.addEventListener('click', async () => {
    const audioId = audioIdInput.value;
    if (!audioId) return;
    
    currentAudioId = audioId;
    
    try {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { action: "GET_AUDIO_URL", id: audioId },
          resolve
        );
      });
      
      if (response.error) {
        statusDisplay.textContent = `Error: ${response.error}`;
        isPlaying = false;
        return;
      }
      
      if (!isPlaying) {
        isPlaying = true;
        statusDisplay.textContent = 'Loading audio...';
        localStorage.setItem("AudioSource", response.url); // сохраняем в localStorage значение
        audioPlayer.src = response.url;
        audioPlayer.volume = 0;
        audioPlayer.load();
        chrome.runtime.sendMessage({
          action: "PLAY_IN_BACKGROUND",
          url: response.url
        });
        audioPlayer.play().then(() => {
          playBtn.style.background = '#ff5100ff';
          statusDisplay.textContent = 'Audio loaded!';
        }).catch(e => {
          statusDisplay.textContent = 'Autoplay blocked: Click play again';
        });
      }
      else {
        audioPlayer.pause();
        audioPlayer.currentTime = 0;
        chrome.runtime.sendMessage({
          action: "STOP_IN_BACKGROUND",
        });
        playBtn.style.background = '#d8e84aff';
        isPlaying = false;
      }
    } catch (error) {
      statusDisplay.textContent = `Error: ${error.message}`;
    }
  });
  
  // Player controls
  audioPlayer.addEventListener('timeupdate', () => {
    const percent = (audioPlayer.currentTime / audioPlayer.duration) * 100;
    progressBar.style.width = `${percent}%`;
    
    const formatTime = (time) => {
      const mins = Math.floor(time / 60);
      const secs = Math.floor(time % 60);
      return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
    };
    
    timeDisplay.textContent = `${formatTime(audioPlayer.currentTime)} / ${formatTime(audioPlayer.duration)}`;
  });
  
  audioPlayer.addEventListener('ended', () => {
    if (isLooping) {
      audioPlayer.currentTime = 0;
      audioPlayer.play();
    } else {
      audioPlayer.pause();
      audioPlayer.currentTime = 0;
      chrome.runtime.sendMessage({
        action: "STOP_IN_BACKGROUND",
      });
      playBtn.style.background = '#d8e84aff';
      isPlaying = false;
    }
  });
  
  // Progress bar
  progress.addEventListener('click', (e) => {
    const rect = progress.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    if (audioPlayer.duration == "Infinity") {
      audioPlayer.src = localStorage.getItem("AudioSource");
      audioPlayer.load();
      audioPlayer.currentTime = pos * audioPlayer.duration;
      chrome.runtime.sendMessage({
        action: "POSITION_IN_BACKGROUND",
        positi: pos * audioPlayer.duration,
      });
    }
    else {
      audioPlayer.currentTime = pos * audioPlayer.duration;
      chrome.runtime.sendMessage({
        action: "POSITION_IN_BACKGROUND",
        positi: pos * audioPlayer.duration,
      });
    }
  });
  
  // Volume control
  volume.addEventListener('click', (e) => {
    const rect = volume.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    currentVolume = Math.max(0, Math.min(1, pos));
    volumeLevel.style.width = `${currentVolume * 100}%`;
    volumeText.textContent = `${Math.round(currentVolume * 100)}%`;

    chrome.runtime.sendMessage({
        action: "VOLUME_IN_BACKGROUND",
        vol: currentVolume
    });
    
    if (isMuted) {
      isMuted = false;
      audioPlayer.muted = false;
      muteBtn.querySelector('.icon').textContent = '🔊';
      muteBtn.querySelector('span:last-child').textContent = 'Mute';
    }
  });
  
  // Mute button
  muteBtn.addEventListener('click', () => {
    isMuted = !isMuted;
    audioPlayer.muted = isMuted;
    chrome.runtime.sendMessage({
        action: "Mute_IN_BACKGROUND",
        mut: isMuted
    });
    muteBtn.querySelector('.icon').textContent = isMuted ? '🔇' : '🔊';
    muteBtn.querySelector('span:last-child').textContent = isMuted ? 'Unmute' : 'Mute';
  });
  
  // Loop button
  loopBtn.addEventListener('click', () => {
    isLooping = !isLooping;
    chrome.runtime.sendMessage({
        action: "LOOP_IN_BACKGROUND",
        lop: isLooping
    });
    loopBtn.classList.toggle('active', isLooping);
    loopBtn.querySelector('span:last-child').textContent = isLooping ? 'On' : 'Loop';
  });
  
  // Mini player button
  miniBtn.addEventListener('click', () => {
    // Placeholder for mini player functionality
    chrome.runtime.sendMessage({
          action: "STOP_IN_BACKGROUND",
    });
    statusDisplay.textContent = 'Mini player stopped!';
  });
  
  // Resize canvas on window resize
  window.addEventListener('resize', () => {
    visualizer.width = visualizer.offsetWidth;
    visualizer.height = visualizer.offsetHeight;
  });
  
  // Initialize player
  initPlayer();
});