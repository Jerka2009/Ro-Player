document.addEventListener('DOMContentLoaded', () => {
  const audioIdInput = document.getElementById('audioId');
  const playBtn = document.getElementById('playBtn');
  const playPauseBtn = document.getElementById('playPauseBtn');
  const stopBtn = document.getElementById('stopBtn');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const loopBtn = document.getElementById('loopBtn');
  const muteBtn = document.getElementById('muteBtn');
  const downloadBtn = document.getElementById('downloadBtn');
  const clearBtn = document.getElementById('clearBtn');
  const progress = document.getElementById('progress');
  const progressBar = document.getElementById('progress-bar');
  const volume = document.getElementById('volume');
  const volumeLevel = document.getElementById('volume-level');
  const volumeText = document.getElementById('volume-text');
  const timeDisplay = document.getElementById('time');
  const statusDisplay = document.getElementById('status');
  const audioPlayer = document.getElementById('audioPlayer');
  
  let currentAudioId = null;
  let isPlaying = false;
  let isMuted = false;
  let currentVolume = 0.8;
  let history = [];
  
  audioPlayer.volume = currentVolume;
  volumeLevel.style.width = `${currentVolume * 100}%`;
  volumeText.textContent = `${Math.round(currentVolume * 100)}%`;
  
  const loadHistory = () => {
    const savedHistory = localStorage.getItem('audioHistory');
    if (savedHistory) {
      history = JSON.parse(savedHistory);
    }
  };

  const saveHistory = () => {
    localStorage.setItem('audioHistory', JSON.stringify(history));
  };

  loadHistory();
  
  // Кнопка Play/Load
  playBtn.addEventListener('click', () => {
    const audioId = audioIdInput.value;
    if (!audioId) return;
    
    currentAudioId = audioId;
    statusDisplay.textContent = 'Loading audio...';
    
    chrome.runtime.sendMessage(
      { action: "GET_AUDIO_URL", id: audioId },
      (response) => {
        if (response.error) {
          statusDisplay.textContent = `Error: ${response.error}`;
          return;
        }
        
        // Добавляем в историю
        if (!history.includes(audioId)) {
            history.push(audioId);
            saveHistory(); // Сохраняем в localStorage
        }
        
        audioPlayer.src = response.url;
        audioPlayer.load();
        audioPlayer.play().then(() => {
          isPlaying = true;
          playPauseBtn.textContent = '⏸';
          statusDisplay.textContent = 'Playing...';
        }).catch(e => {
          statusDisplay.textContent = 'Playback failed. Click play button.';
        });
      }
    );
  });
  
  playPauseBtn.addEventListener('click', () => {
    if (audioPlayer.src) {
      if (isPlaying) {
        audioPlayer.pause();
        playPauseBtn.textContent = '⏯';
        statusDisplay.textContent = 'Paused';
      } else {
        audioPlayer.play();
        playPauseBtn.textContent = '⏸';
        statusDisplay.textContent = 'Playing...';
      }
      isPlaying = !isPlaying;
    }
  });
  
  stopBtn.addEventListener('click', () => {
    audioPlayer.pause();
    audioPlayer.currentTime = 0;
    isPlaying = false;
    playPauseBtn.textContent = '⏯';
    statusDisplay.textContent = 'Stopped';
  });
  
  loopBtn.addEventListener('click', () => {
    audioPlayer.loop = !audioPlayer.loop;
    loopBtn.style.background = audioPlayer.loop ? '#900' : '';
    statusDisplay.textContent = audioPlayer.loop ? 'Loop enabled' : 'Loop disabled';
  });
  
  muteBtn.addEventListener('click', () => {
    isMuted = !isMuted;
    audioPlayer.muted = isMuted;
    muteBtn.textContent = isMuted ? '🔇 Unmute' : '🔊 Mute';
    muteBtn.style.background = isMuted ? '#900' : '';
  });
  
  progress.addEventListener('click', (e) => {
    const rect = progress.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    audioPlayer.currentTime = pos * audioPlayer.duration;
  });
  
  audioPlayer.addEventListener('timeupdate', () => {
    const percent = (audioPlayer.currentTime / audioPlayer.duration) * 100;
    progressBar.style.width = `${percent}%`;
    
    const formatTime = (time) => {
      const mins = Math.floor(time / 60);
      const secs = Math.floor(time % 60);
      return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
    };
    
    timeDisplay.textContent = `${formatTime(audioPlayer.currentTime)} / ${formatTime(audioPlayer.duration)}`;
  });
  
  volume.addEventListener('click', (e) => {
    const rect = volume.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    currentVolume = Math.max(0, Math.min(1, pos));
    audioPlayer.volume = currentVolume;
    volumeLevel.style.width = `${currentVolume * 100}%`;
    volumeText.textContent = `${Math.round(currentVolume * 100)}%`;
    
    if (isMuted) {
      isMuted = false;
      audioPlayer.muted = false;
      muteBtn.textContent = '🔊 Mute';
      muteBtn.style.background = '';
    }
  });
  
  audioPlayer.addEventListener('ended', () => {
    isPlaying = false;
    playPauseBtn.textContent = '⏯';
    statusDisplay.textContent = 'Playback finished';
  });
});